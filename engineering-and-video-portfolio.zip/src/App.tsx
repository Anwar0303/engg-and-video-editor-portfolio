import { useEffect, useRef, useState } from "react";
import {
  ArrowRight, ArrowUpRight, BadgeCheck, Braces, Briefcase, Calendar, Check, ChevronDown, ChevronLeft, ChevronRight,
  Clapperboard, Clock, Code2, Cpu, Download, Eye, Film, Heart, Layers, Mail, MapPin,
  Menu, MonitorPlay, MousePointerClick, Pause, Play, Scissors, Send, SkipBack, SkipForward, Sparkles, Star, Terminal,
  Volume2, Wand2, X, Zap, Aperture, CircuitBoard, Rocket, Quote, Globe, AtSign, MessageCircle, Camera
} from "lucide-react";

/* ---------- hooks ---------- */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    const io = new IntersectionObserver((es) => es.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); }), { threshold: 0.12 });
    els.forEach(el => io.observe(el));
    return () => io.disconnect();
  }, []);
}
function useCounter(target: number, start: boolean, dur = 1600) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!start) return;
    let raf = 0; const t0 = performance.now();
    const tick = (t: number) => { const p = Math.min(1, (t - t0) / dur); setV(Math.round(target * (1 - Math.pow(1 - p, 3)))); if (p < 1) raf = requestAnimationFrame(tick); };
    raf = requestAnimationFrame(tick); return () => cancelAnimationFrame(raf);
  }, [start, target, dur]);
  return v;
}

/* ---------- data ---------- */
type Mode = "eng" | "edit";
type Cat = "All" | "Engineering" | "Video Editing" | "Hybrid";

const projects = [
  { id:1, cat:"Engineering", title:"NeuroVision Edge AI", desc:"Real-time object detection on Raspberry Pi + custom PCB. 38 FPS at 4W — deployed for smart traffic counting.", img:"https://images.pexels.com/photos/40342986/pexels-photo-40342986.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", tags:["Python","C++","TensorFlow Lite","PCB Design"], metric:"★ 2.4k GitHub", metricLabel:"Open Source", accent:"cyan", result:"+62% accuracy vs baseline" },
  { id:2, cat:"Video Editing", title:"\"WANDER\" — Travel Film", desc:"12-minute cinematic travel film. Shot on Sony A7S III, graded in DaVinci, sound-designed from scratch.", img:"https://images.pexels.com/photos/19224452/pexels-photo-19224452.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", tags:["Premiere Pro","DaVinci Resolve","Sound Design"], metric:"▶ 4.8M views", metricLabel:"YouTube • 28 days", accent:"rose", result:"1.2M views in first week" },
  { id:3, cat:"Hybrid", title:"StreamForge — Live Studio Tool", desc:"I built the software AND cut the launch film. OBS automation plugin + 90-sec product trailer that converted.", img:"https://images.pexels.com/photos/29505140/pexels-photo-29505140.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", tags:["React","Node.js","After Effects","OBS API"], metric:"↗ 34% conversion", metricLabel:"Product Launch", accent:"violet", result:"12k signups launch week" },
  { id:4, cat:"Engineering", title:"PulseOS — Embedded Firmware", desc:"Low-power RTOS for a wearable health tracker. 21-day battery, BLE sync, OTA updates, custom drivers.", img:"https://images.pexels.com/photos/3665442/pexels-photo-3665442.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", tags:["Embedded C","RTOS","ARM Cortex","BLE"], metric:"21 days battery", metricLabel:"Wearable Tech", accent:"cyan", result:"-40% power consumption" },
  { id:5, cat:"Video Editing", title:"Brand Reels That Sell", desc:"40+ short-form edits for DTC brands — hooks in 0.8s, captions that retain, cuts synced to the beat.", img:"https://images.pexels.com/photos/29224578/pexels-photo-29224578.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", tags:["CapCut Pro","Premiere","Motion GFX","Captions"], metric:"▶ 48M total views", metricLabel:"Reels / TikTok / Shorts", accent:"rose", result:"3.7x average watch time" },
  { id:6, cat:"Engineering", title:"DevBoard — Full-Stack Platform", desc:"SaaS analytics dashboard processing 2M events/day. React frontend, Go microservices, realtime charts.", img:"https://images.pexels.com/photos/5473301/pexels-photo-5473301.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", tags:["TypeScript","React","Go","PostgreSQL"], metric:"2M events / day", metricLabel:"SaaS Platform", accent:"cyan", result:"99.98% uptime • 180ms p95" },
];

const reelClips = [
  { name:"A_ROLL_01.mp4", label:"Opening — City Awakens", start:0, end:25, img:"https://images.pexels.com/photos/19224452/pexels-photo-19224452.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", color:"bg-rose-500" },
  { name:"B_ROLL_04.mp4", label:"The Chase — Gimbal Run", start:25, end:52, img:"https://images.pexels.com/photos/29224578/pexels-photo-29224578.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", color:"bg-violet-500" },
  { name:"INT_02.mp4", label:"Behind The Scenes", start:52, end:78, img:"https://images.pexels.com/photos/32610376/pexels-photo-32610376.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", color:"bg-cyan-500" },
  { name:"FINAL_GRADE.mp4", label:"Final Grade — Sunset Cut", start:78, end:100, img:"https://images.pexels.com/photos/29505140/pexels-photo-29505140.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200", color:"bg-amber-500" },
];

const engSkills = [
  { name:"C / C++ & Embedded Systems", level:94 }, { name:"Python & AI / Computer Vision", level:90 },
  { name:"React / TypeScript / Node", level:92 }, { name:"PCB Design & IoT Hardware", level:85 },
  { name:"System Design & Databases", level:88 },
];
const editSkills = [
  { name:"Premiere Pro — Narrative Cutting", level:96 }, { name:"After Effects — Motion Graphics", level:91 },
  { name:"DaVinci Resolve — Color Grading", level:93 }, { name:"Sound Design & Mixing", level:87 },
  { name:"Short-Form Retention Editing", level:95 },
];

const testimonials = [
  { quote:"Alex is the rarest hire we've made. He debugged our firmware in the morning and cut a launch film by evening that got us 12,000 signups. One person, two superpowers.", name:"Sarah Linden", role:"CEO, StreamForge", initials:"SL", color:"bg-cyan-500" },
  { quote:"Our reels went from 40k to 2.1M views in six weeks. He doesn't just edit — he engineers attention. Every cut has a reason, every hook is tested.", name:"Marcus Chen", role:"Founder, NOMAD Apparel", initials:"MC", color:"bg-rose-500" },
  { quote:"Clean architecture, clean timelines. Delivered an embedded system 2 weeks early and documented it better than teams 5x his size. We rehire him every quarter.", name:"Dr. Priya Nair", role:"CTO, PulseWear Health", initials:"PN", color:"bg-violet-500" },
];

const faqs = [
  { q:"Can you really do both — engineering and editing?", a:"Yes, and that's the advantage. I build tools that make editing faster (automation scripts, plugins, templates) and I edit with an engineer's precision — frame-accurate, systemized, and data-driven." },
  { q:"What's your typical turnaround?", a:"Short-form reels: 24–48h. Long-form YouTube: 3–5 days. Software MVPs: 2–4 weeks. Rush delivery available — I keep a structured pipeline so quality never drops under pressure." },
  { q:"Do you work remotely with international clients?", a:"100% remote, async-friendly. I've shipped for clients in the US, UK, UAE & India. Daily updates, shared boards, and Loom walkthroughs so you always know the status." },
  { q:"What do you need from me to start?", a:"For editing: raw footage + 2–3 reference videos you love. For engineering: a short brief or even a voice note. I'll reply within 12 hours with scope, timeline and a fixed quote." },
];

function fmt(sec:number){ const m=Math.floor(sec/60), s=Math.floor(sec%60); return `00:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}:${String(Math.floor((sec%1)*24)).padStart(2,"0")}`; }

export default function App(){
  useReveal();
  const [mode,setMode]=useState<Mode>("edit");
  const [filter,setFilter]=useState<Cat>("All");
  const [skillTab,setSkillTab]=useState<Mode>("eng");
  const [mobile,setMobile]=useState(false);
  const [scrolled,setScrolled]=useState(false);
  const [selected,setSelected]=useState<typeof projects[0]|null>(null);
  const [testi,setTesti]=useState(0);
  const [openFaq,setOpenFaq]=useState(0);
  const [form,setForm]=useState({name:"",email:"",type:"Video Editing Project",budget:"$500 – $1k",msg:""});
  const [sent,setSent]=useState(false);
  const [liked,setLiked]=useState<number[]>([]);
  // showreel
  const [playing,setPlaying]=useState(false);
  const [progress,setProgress]=useState(18); // 0-100 sec mapped
  const DUR=100;
  // terminal typing
  const [typed,setTyped]=useState("");
  const codeLine = mode==="eng" ? "const future = await build({ vision: true, story: true });" : "timeline.cut({ at: '00:00:12:08', effect: 'impact' }); // ✂ perfect";
  // counters
  const statsRef=useRef<HTMLDivElement>(null);
  const [statsVisible,setStatsVisible]=useState(false);

  useEffect(()=>{ const on=()=>setScrolled(window.scrollY>30); window.addEventListener("scroll",on); return ()=>window.removeEventListener("scroll",on); },[]);
  useEffect(()=>{ const t=setInterval(()=>setTesti(v=>(v+1)%testimonials.length),6000); return ()=>clearInterval(t); },[]);
  useEffect(()=>{
    if(!playing) return;
    const id=setInterval(()=>setProgress(p=>{ if(p>=DUR){ setPlaying(false); return DUR; } return +(p+0.2).toFixed(2); }),100);
    return ()=>clearInterval(id);
  },[playing]);
  useEffect(()=>{
    setTyped(""); let i=0; const id=setInterval(()=>{ i++; setTyped(codeLine.slice(0,i)); if(i>=codeLine.length) clearInterval(id); },32);
    return ()=>clearInterval(id);
  },[mode]); // eslint-disable-line
  useEffect(()=>{
    const io=new IntersectionObserver(es=>es.forEach(e=>{ if(e.isIntersecting) setStatsVisible(true); }),{threshold:.3});
    if(statsRef.current) io.observe(statsRef.current); return ()=>io.disconnect();
  },[]);

  const activeClip = reelClips.find(c=>progress>=c.start && progress<c.end) || reelClips[reelClips.length-1];
  const filtered = filter==="All" ? projects : projects.filter(p=>p.cat===filter);
  const c1=useCounter(120,statsVisible), c2=useCounter(48,statsVisible), c3=useCounter(36,statsVisible), c4=useCounter(98,statsVisible);

  const seek = (e:React.MouseEvent<HTMLDivElement>)=>{ const r=e.currentTarget.getBoundingClientRect(); setProgress(Math.round(((e.clientX-r.left)/r.width)*DUR)); };

  return (
    <div className="min-h-screen bg-[#08080d] text-zinc-100 antialiased overflow-x-clip">
      {/* NAV */}
      <header className={`fixed top-0 inset-x-0 z-50 transition-all ${scrolled?"bg-[#08080d]/85 backdrop-blur-xl border-b border-white/10 py-3":"py-5"}`}>
        <div className="max-w-7xl mx-auto px-5 lg:px-8 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-3">
            <div className="relative w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 via-violet-500 to-rose-500 grid place-items-center font-display font-bold text-lg shadow-lg shadow-violet-500/25">A<span className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-400 border-2 border-[#08080d] rounded-full"/></div>
            <div className="leading-none"><p className="font-display font-700 font-bold tracking-tight text-[17px]">ALEX CARTER</p><p className="text-[10px] tracking-[0.22em] text-zinc-400 mt-1">ENGINEER × EDITOR</p></div>
          </a>
          <nav className="hidden lg:flex items-center gap-8 text-sm text-zinc-300">
            {[["Work","#work"],["Showreel","#showreel"],["Skills","#skills"],["Process","#process"],["About","#about"]].map(([l,h])=><a key={h} href={h} className="hover:text-white transition hover:-translate-y-0.5 inline-block">{l}</a>)}
          </nav>
          <div className="flex items-center gap-3">
            <span className="hidden md:inline-flex items-center gap-2 text-xs bg-emerald-400/10 text-emerald-300 border border-emerald-400/20 px-3 py-1.5 rounded-full"><span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"/> Available for Q3 projects</span>
            <a href="#contact" className="hidden sm:inline-flex bg-white text-black text-sm font-semibold px-5 py-2.5 rounded-full hover:bg-cyan-300 transition items-center gap-2">Hire Me <ArrowUpRight className="w-4 h-4"/></a>
            <button onClick={()=>setMobile(!mobile)} className="lg:hidden w-10 h-10 grid place-items-center rounded-full border border-white/10">{mobile?<X className="w-5 h-5"/>:<Menu className="w-5 h-5"/>}</button>
          </div>
        </div>
        {mobile && <div className="lg:hidden mx-5 mt-3 p-4 rounded-2xl glass flex flex-col gap-1">{[["Work","#work"],["Showreel","#showreel"],["Skills","#skills"],["Process","#process"],["About","#about"],["Contact","#contact"]].map(([l,h])=><a key={h} href={h} onClick={()=>setMobile(false)} className="px-3 py-2.5 rounded-xl hover:bg-white/5 font-medium">{l}</a>)}</div>}
      </header>

      {/* HERO */}
      <section id="top" className="relative pt-[130px] lg:pt-[150px] pb-16 grid-bg noise overflow-hidden">
        <div className="absolute -top-32 -left-32 w-[480px] h-[480px] bg-cyan-500/20 blur-[130px] rounded-full pointer-events-none"/>
        <div className="absolute top-20 -right-32 w-[520px] h-[520px] bg-rose-500/15 blur-[130px] rounded-full pointer-events-none"/>
        <div className="absolute bottom-0 left-1/3 w-[400px] h-[300px] bg-violet-600/15 blur-[120px] rounded-full pointer-events-none"/>
        <div className="relative max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-6 reveal visible">
              <div className="inline-flex flex-wrap gap-2">
                <span className="inline-flex items-center gap-2 text-xs font-mono2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full"><Cpu className="w-3.5 h-3.5 text-cyan-300"/> B.E. Computer Engineering</span>
                <span className="inline-flex items-center gap-2 text-xs font-mono2 bg-white/5 border border-white/10 px-3 py-1.5 rounded-full"><Clapperboard className="w-3.5 h-3.5 text-rose-300"/> 48M+ views edited</span>
              </div>
              <h1 className="font-display font-bold leading-[0.95] tracking-tight mt-6 text-[52px] sm:text-[72px] xl:text-[84px]">
                I BUILD<br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-violet-400">SYSTEMS.</span><br/>I CUT <span className="text-shine">STORIES.</span>
              </h1>
              <p className="mt-6 text-zinc-400 text-lg leading-relaxed max-w-xl">Computer Engineer by degree, Video Editor by obsession. I ship embedded systems & full-stack products — and edit films, reels & ads people can't stop watching. <span className="text-zinc-100 font-medium">Logic meets cinema, in one person.</span></p>

              {/* MODE SWITCH */}
              <div className="mt-8">
                <p className="text-[11px] tracking-[0.25em] text-zinc-500 font-mono2 mb-3">◉ SWITCH MY BRAIN — TRY IT</p>
                <div className="inline-flex p-1.5 rounded-2xl bg-white/5 border border-white/10">
                  <button onClick={()=>setMode("eng")} className={`flex items-center gap-2 px-5 sm:px-7 py-3 rounded-xl text-sm font-semibold transition-all ${mode==="eng"?"bg-cyan-400 text-black shadow-lg shadow-cyan-400/25":"text-zinc-300 hover:text-white"}`}><Code2 className="w-4 h-4"/> ENGINEER MODE</button>
                  <button onClick={()=>setMode("edit")} className={`flex items-center gap-2 px-5 sm:px-7 py-3 rounded-xl text-sm font-semibold transition-all ${mode==="edit"?"bg-gradient-to-r from-violet-500 to-rose-500 text-white shadow-lg shadow-rose-500/25":"text-zinc-300 hover:text-white"}`}><Scissors className="w-4 h-4"/> EDITOR MODE</button>
                </div>
                <div className="mt-4 flex items-start gap-3 max-w-xl">
                  <div className={`mt-0.5 w-8 h-8 shrink-0 rounded-lg grid place-items-center ${mode==="eng"?"bg-cyan-400/15 text-cyan-300":"bg-rose-400/15 text-rose-300"}`}>{mode==="eng"?<Terminal className="w-4 h-4"/>:<Film className="w-4 h-4"/>}</div>
                  <p className="text-sm text-zinc-400 leading-relaxed">{mode==="eng" ? <><b className="text-cyan-300 font-semibold">Now thinking in systems:</b> architecture, clean code, hardware that never fails. I design it, build it, ship it.</> : <><b className="text-rose-300 font-semibold">Now thinking in frames:</b> hooks, pacing, color & sound. I cut for retention — every frame earns its place.</>}</p>
                </div>
              </div>

              <div className="mt-8 flex flex-wrap gap-3">
                <a href="#work" className="inline-flex items-center gap-2 bg-white text-black font-semibold px-7 py-3.5 rounded-full hover:scale-[1.03] transition">View My Work <ArrowRight className="w-4 h-4"/></a>
                <a href="#showreel" className="inline-flex items-center gap-2 border border-white/15 px-6 py-3.5 rounded-full font-semibold hover:bg-white/5 transition"><span className="w-7 h-7 rounded-full bg-rose-500 grid place-items-center animate-pulse-ring"><Play className="w-3.5 h-3.5 fill-white"/></span> Watch Showreel <span className="text-zinc-500 text-sm font-normal">1:40</span></a>
                <button className="inline-flex items-center gap-2 text-sm text-zinc-300 px-4 py-3.5 hover:text-white transition"><Download className="w-4 h-4"/> Résumé</button>
              </div>

              <div className="mt-9 flex items-center gap-4">
                <div className="flex -space-x-3">{["bg-cyan-500","bg-violet-500","bg-rose-500","bg-amber-500"].map((c,i)=><div key={i} className={`w-10 h-10 rounded-full ${c} border-2 border-[#08080d] grid place-items-center text-xs font-bold`}>{["SL","MC","PN","+" ][i]}</div>)}
                </div>
                <div><div className="flex gap-0.5">{[1,2,3,4,5].map(i=><Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400"/>) }<span className="text-sm font-semibold ml-1">5.0</span></div><p className="text-xs text-zinc-500 mt-0.5">from 36+ clients across 9 countries</p></div>
              </div>
            </div>

            {/* HERO VISUAL CARD */}
            <div className="lg:col-span-6 reveal visible">
              <div className="relative">
                <div className="absolute -inset-3 bg-gradient-to-r from-cyan-500/20 via-violet-500/20 to-rose-500/20 blur-2xl rounded-[32px]"/>
                <div className="relative rounded-[28px] overflow-hidden border border-white/10 bg-[#0c0c14] shadow-2xl">
                  <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/8 bg-white/[0.03]">
                    <div className="flex gap-2"><span className="w-3 h-3 rounded-full bg-rose-500"/><span className="w-3 h-3 rounded-full bg-amber-400"/><span className="w-3 h-3 rounded-full bg-emerald-400"/></div>
                    <p className="font-mono2 text-xs text-zinc-400">{mode==="eng"?"alex@engine: ~/future — zsh":"Premiere Pro — WANDER_final_v9.prproj"}</p>
                    <span className={`text-[10px] font-mono2 px-2 py-1 rounded-md ${mode==="eng"?"bg-cyan-400/10 text-cyan-300":"bg-rose-400/10 text-rose-300"}`}>{mode==="eng"?"● COMPILING":"● RENDERING 98%"}</span>
                  </div>

                  {mode==="eng" ? (
                    <div className="p-5 sm:p-6">
                      <div className="rounded-2xl overflow-hidden relative h-[240px] sm:h-[280px]">
                        <img src="https://images.pexels.com/photos/40342986/pexels-photo-40342986.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200" alt="Circuit board engineering" className="w-full h-full object-cover"/>
                        <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent"/>
                        <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end"><div><p className="font-mono2 text-[10px] tracking-widest text-cyan-300">CURRENT BUILD</p><p className="font-display font-bold text-lg leading-tight mt-1">NeuroVision Edge AI — PCB v3</p></div><span className="text-xs bg-cyan-400 text-black font-bold px-2.5 py-1 rounded-lg">38 FPS</span></div>
                      </div>
                      <div className="mt-4 bg-black/60 border border-white/10 rounded-2xl p-4 font-mono2 text-[13px] leading-relaxed overflow-hidden">
                        <p><span className="text-zinc-500">01</span> <span className="text-violet-300">import</span> <span className="text-cyan-300">{"{ vision, story }"}</span> <span className="text-violet-300">from</span> <span className="text-amber-300">'@alex/brain'</span>;</p>
                        <p><span className="text-zinc-500">02</span> <span className="text-zinc-300">{typed}</span><span className="animate-blink text-cyan-300">▌</span></p>
                        <p><span className="text-zinc-500">03</span> <span className="text-emerald-400">✓ deployed</span> <span className="text-zinc-500">— 0 errors, 12ms latency, shipped 🚀</span></p>
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">{["C++","Python","React / TS","Embedded","PCB","AI / CV"].map(s=><span key={s} className="text-xs bg-cyan-400/10 text-cyan-200 border border-cyan-400/20 px-3 py-1.5 rounded-full">{s}</span>)}</div>
                    </div>
                  ) : (
                    <div className="p-5 sm:p-6">
                      <div className="rounded-2xl overflow-hidden relative h-[240px] sm:h-[280px] group cursor-pointer" onClick={()=>{ document.getElementById("showreel")?.scrollIntoView({behavior:"smooth"}); }}>
                        <img src="https://images.pexels.com/photos/8102677/pexels-photo-8102677.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200" alt="Video editor at work" className="w-full h-full object-cover group-hover:scale-105 transition duration-700"/>
                        <div className="absolute inset-0 bg-black/35"/>
                        <div className="absolute inset-0 grid place-items-center"><span className="w-16 h-16 rounded-full bg-white text-black grid place-items-center shadow-2xl group-hover:scale-110 transition animate-pulse-ring"><Play className="w-6 h-6 fill-black ml-1"/></span></div>
                        <span className="absolute top-3 left-3 text-[10px] font-mono2 bg-black/60 backdrop-blur px-2.5 py-1 rounded-md">REC ● 4K 24FPS</span>
                        <span className="absolute bottom-3 right-3 text-[10px] font-mono2 bg-black/60 backdrop-blur px-2.5 py-1 rounded-md">SHOWREEL_2025.mp4</span>
                        <div className="absolute bottom-3 left-3 flex items-end gap-1 h-8">{[14,22,10,28,18,30,12,24,16,26].map((h,i)=><span key={i} className="eq-bar w-1.5 bg-rose-400 rounded-full" style={{height:h, animationDelay:`${i*0.12}s`}}/>)}</div>
                      </div>
                      {/* mini timeline */}
                      <div className="mt-4 bg-black/60 border border-white/10 rounded-2xl p-4">
                        <div className="flex justify-between font-mono2 text-[10px] text-zinc-500 mb-2"><span>00:00:00:00</span><span className="text-rose-300">{typed ? "▶ PLAYING" : ""}</span><span>00:01:40:00</span></div>
                        <div className="space-y-1.5 relative">
                          <div className="absolute top-0 bottom-0 w-px bg-rose-500 z-10" style={{left:"38%"}}><span className="absolute -top-1 -left-[5px] w-[11px] h-[11px] bg-rose-500 rotate-45 rounded-[2px]"/></div>
                          <div className="flex gap-1"><span className="w-8 text-[9px] font-mono2 text-zinc-500 pt-1">V2</span><div className="flex-1 h-5 rounded bg-violet-500/70"/><div className="w-1/4 h-5 rounded bg-violet-400/50"/></div>
                          <div className="flex gap-1"><span className="w-8 text-[9px] font-mono2 text-zinc-500 pt-1">V1</span><div className="w-1/3 h-5 rounded bg-rose-500/80"/><div className="flex-1 h-5 rounded bg-rose-400/60"/><div className="w-1/5 h-5 rounded bg-amber-400/70"/></div>
                          <div className="flex gap-1"><span className="w-8 text-[9px] font-mono2 text-zinc-500 pt-1">A1</span><div className="flex-1 h-4 rounded bg-emerald-500/40 flex items-center px-2 gap-[2px]">{Array.from({length:42}).map((_,i)=><span key={i} className="w-[2px] bg-emerald-300/80 rounded" style={{height: 4+((i*7)%9)}}/>)}</div></div>
                        </div>
                        <p className="font-mono2 text-[11px] text-zinc-400 mt-3 truncate"><span className="text-rose-300">$</span> {typed}<span className="animate-blink">▌</span></p>
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">{["Premiere Pro","After Effects","DaVinci","Audition","CapCut Pro"].map(s=><span key={s} className="text-xs bg-rose-400/10 text-rose-200 border border-rose-400/20 px-3 py-1.5 rounded-full">{s}</span>)}</div>
                    </div>
                  )}
                </div>
                <div className="absolute -left-3 sm:-left-6 top-16 glass rounded-2xl px-4 py-3 animate-floaty hidden sm:block"><p className="text-[10px] text-zinc-400 tracking-wider">CODE COMMITS</p><p className="font-display font-bold">3,842 <span className="text-emerald-400 text-xs">↑ 18%</span></p></div>
                <div className="absolute -right-2 sm:-right-5 bottom-24 glass rounded-2xl px-4 py-3 animate-floaty hidden sm:block" style={{animationDelay:"1.2s"}}><p className="text-[10px] text-zinc-400 tracking-wider">VIEWS GENERATED</p><p className="font-display font-bold">48M+ <span className="text-rose-400 text-xs">▶ viral ×7</span></p></div>
              </div>
            </div>
          </div>

          {/* STATS */}
          <div ref={statsRef} className="mt-16 grid grid-cols-2 lg:grid-cols-4 rounded-3xl border border-white/10 bg-white/[0.03] overflow-hidden reveal">
            {[{v:c1,suffix:"+",label:"Projects Shipped",sub:"Engineering + Video",icon:Briefcase,color:"text-cyan-300"},{v:c2,suffix:"M+",label:"Views Generated",sub:"Across all platforms",icon:Eye,color:"text-rose-300"},{v:c3,suffix:"+",label:"Happy Clients",sub:"9 countries, 5★ rated",icon:Heart,color:"text-violet-300"},{v:c4,suffix:"%",label:"On-Time Delivery",sub:"Rush jobs included",icon:Zap,color:"text-amber-300"}].map((s,i)=>(
              <div key={i} className={`p-6 sm:p-7 ${i!==0?"border-l border-white/8":""} ${i>=2?"max-lg:border-t max-lg:border-white/8":""} ${i===2?"max-lg:border-l-0":""}`}>
                <s.icon className={`w-5 h-5 ${s.color}`}/><p className="font-display text-4xl font-bold mt-3">{s.v}{s.suffix}</p><p className="font-medium mt-1 text-sm">{s.label}</p><p className="text-xs text-zinc-500 mt-0.5">{s.sub}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* MARQUEE */}
      <div className="border-y border-white/8 bg-[#0a0a12] py-4 overflow-hidden -rotate-[0.4deg] scale-[1.01]">
        <div className="flex whitespace-nowrap animate-marquee w-max">
          {[0,1].map(k=><div key={k} className="flex items-center">{["REACT","TYPESCRIPT","PREMIERE PRO","C++","AFTER EFFECTS","PYTHON","DAVINCI RESOLVE","EMBEDDED C","PCB DESIGN","NODE.JS","COLOR GRADING","TENSORFLOW","SOUND DESIGN","DOCKER"].map(t=><span key={t} className="mx-5 font-display font-semibold tracking-wide text-zinc-400 flex items-center gap-5">{t}<Sparkles className="w-4 h-4 text-violet-400"/></span>)}</div>)}
        </div>
      </div>

      {/* DUAL IDENTITY */}
      <section id="about" className="py-24 relative">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="reveal flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div><p className="font-mono2 text-xs tracking-[0.3em] text-cyan-300">01 — THE DUAL IDENTITY</p><h2 className="font-display text-4xl sm:text-5xl font-bold mt-3 leading-tight">Left brain builds it.<br/>Right brain films it.</h2></div>
            <p className="text-zinc-400 max-w-sm text-sm leading-relaxed">Most people hire two freelancers and manage the gap between them. My clients hire one mind where engineering & storytelling already talk to each other.</p>
          </div>

          <div className="grid lg:grid-cols-2 gap-6 mt-12">
            <div className="reveal group relative rounded-[28px] overflow-hidden border border-cyan-400/20 bg-gradient-to-b from-cyan-400/[0.07] to-transparent p-7 sm:p-9 hover:border-cyan-400/40 transition">
              <img src="https://images.pexels.com/photos/34212916/pexels-photo-34212916.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200" alt="Coding workspace" className="absolute inset-0 w-full h-full object-cover opacity-[0.13] group-hover:opacity-[0.22] group-hover:scale-105 transition duration-700"/>
              <div className="relative">
                <div className="flex justify-between"><span className="w-14 h-14 rounded-2xl bg-cyan-400 text-black grid place-items-center"><CircuitBoard className="w-7 h-7"/></span><span className="font-mono2 text-xs text-cyan-300 bg-cyan-400/10 border border-cyan-400/20 px-3 py-1.5 rounded-full h-fit">5+ YEARS</span></div>
                <h3 className="font-display text-3xl font-bold mt-6">Computer Engineering</h3>
                <p className="text-zinc-400 mt-3 leading-relaxed text-[15px]">From bare-metal firmware to cloud dashboards. I think in systems, debug in my sleep, and treat every product like hardware — it has to work every single time.</p>
                <ul className="mt-6 space-y-3 text-sm">{["Embedded systems, IoT & custom PCB products","Full-stack apps — React, TypeScript, Node, Go","AI / Computer Vision pipelines that run on the edge","Clean, documented, tested code. Always."].map(x=><li key={x} className="flex gap-3"><Check className="w-4.5 h-4.5 w-5 h-5 text-cyan-300 shrink-0"/>{x}</li>)}</ul>
                <button onClick={()=>{setFilter("Engineering"); document.getElementById("work")?.scrollIntoView({behavior:"smooth"});}} className="mt-8 inline-flex items-center gap-2 text-cyan-300 font-semibold text-sm hover:gap-3 transition-all">See engineering work <ArrowRight className="w-4 h-4"/></button>
              </div>
            </div>

            <div className="reveal group relative rounded-[28px] overflow-hidden border border-rose-400/20 bg-gradient-to-b from-rose-400/[0.07] to-transparent p-7 sm:p-9 hover:border-rose-400/40 transition">
              <img src="https://images.pexels.com/photos/695730/pexels-photo-695730.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200" alt="Editing timeline" className="absolute inset-0 w-full h-full object-cover opacity-[0.13] group-hover:opacity-[0.22] group-hover:scale-105 transition duration-700"/>
              <div className="relative">
                <div className="flex justify-between"><span className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500 to-rose-500 text-white grid place-items-center"><Aperture className="w-7 h-7"/></span><span className="font-mono2 text-xs text-rose-300 bg-rose-400/10 border border-rose-400/20 px-3 py-1.5 rounded-full h-fit">300+ VIDEOS CUT</span></div>
                <h3 className="font-display text-3xl font-bold mt-6">Video Editing</h3>
                <p className="text-zinc-400 mt-3 leading-relaxed text-[15px]">Retention is my religion. I study analytics like logs, A/B test hooks like features, and cut until a stranger becomes a subscriber — or a customer.</p>
                <ul className="mt-6 space-y-3 text-sm">{["YouTube long-form that holds 55%+ retention","Reels / Shorts engineered for the first 0.8 seconds","Cinematic color grading & full sound design","Ads & product films that actually convert"].map(x=><li key={x} className="flex gap-3"><Check className="w-5 h-5 text-rose-300 shrink-0"/>{x}</li>)}</ul>
                <button onClick={()=>{setFilter("Video Editing"); document.getElementById("work")?.scrollIntoView({behavior:"smooth"});}} className="mt-8 inline-flex items-center gap-2 text-rose-300 font-semibold text-sm hover:gap-3 transition-all">See editing work <ArrowRight className="w-4 h-4"/></button>
              </div>
            </div>
          </div>

          {/* ABOUT STRIP */}
          <div className="reveal mt-6 grid lg:grid-cols-12 gap-6 items-stretch">
            <div className="lg:col-span-4 rounded-[28px] overflow-hidden relative min-h-[280px]">
              <img src="https://images.pexels.com/photos/23897427/pexels-photo-23897427.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800" alt="Alex Carter portrait" className="absolute inset-0 w-full h-full object-cover"/>
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-transparent to-transparent"/>
              <div className="absolute bottom-5 left-5"><p className="font-display font-bold text-xl">Alex Carter, 26</p><p className="text-sm text-zinc-300 flex items-center gap-1.5 mt-1"><MapPin className="w-3.5 h-3.5"/> Remote • Working worldwide</p></div>
              <span className="absolute top-4 left-4 text-[10px] font-mono2 bg-black/60 backdrop-blur px-2.5 py-1 rounded-md">EST. 2020 — STILL COMPILING</span>
            </div>
            <div className="lg:col-span-8 rounded-[28px] border border-white/10 bg-white/[0.03] p-7 sm:p-9 flex flex-col justify-between">
              <div>
                <Quote className="w-8 h-8 text-violet-400"/>
                <p className="font-display text-2xl sm:text-[28px] leading-snug font-medium mt-4">"Engineering taught me <span className="text-cyan-300">how things work</span>. Editing taught me <span className="text-rose-300">how people feel</span>. I refuse to choose — so I mastered both, and now my code ships with a story and my stories ship with a system."</p>
              </div>
              <div className="flex flex-wrap gap-x-8 gap-y-3 mt-8 text-sm text-zinc-400">
                <span className="flex items-center gap-2"><BadgeCheck className="w-4 h-4 text-emerald-400"/> B.E. Computer Engineering, Honors</span>
                <span className="flex items-center gap-2"><BadgeCheck className="w-4 h-4 text-emerald-400"/> Adobe Certified Professional</span>
                <span className="flex items-center gap-2"><BadgeCheck className="w-4 h-4 text-emerald-400"/> AWS Cloud Practitioner</span>
                <span className="flex items-center gap-2"><Clock className="w-4 h-4 text-amber-400"/> Replies within 12 hours</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WORK */}
      <section id="work" className="py-24 bg-[#0a0a12] border-y border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-violet-600/10 blur-[120px] rounded-full"/>
        <div className="max-w-7xl mx-auto px-5 lg:px-8 relative">
          <div className="reveal flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div><p className="font-mono2 text-xs tracking-[0.3em] text-rose-300">02 — SELECTED WORK</p><h2 className="font-display text-4xl sm:text-5xl font-bold mt-3">Built. Cut. <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-violet-400 to-rose-400">Shipped.</span></h2><p className="text-zinc-400 mt-3 max-w-lg text-sm leading-relaxed">Click any project for the full story. Filter by discipline — or see the hybrid projects where both brains fired at once.</p></div>
            <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-white/5 border border-white/10 w-fit">
              {(["All","Engineering","Video Editing","Hybrid"] as Cat[]).map(c=><button key={c} onClick={()=>setFilter(c)} className={`px-4 sm:px-5 py-2.5 rounded-xl text-sm font-medium transition ${filter===c?"bg-white text-black":"text-zinc-300 hover:text-white"}`}>{c}</button>)}
            </div>
          </div>

          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6 mt-12">
            {filtered.map((p)=>(
              <article key={p.id} onClick={()=>setSelected(p)} className="reveal visible group cursor-pointer rounded-[24px] overflow-hidden bg-white/[0.03] border border-white/10 hover:border-white/25 hover:-translate-y-1.5 transition-all duration-300">
                <div className="relative h-52 overflow-hidden">
                  <img src={p.img} alt={p.title} className="w-full h-full object-cover group-hover:scale-110 transition duration-700"/>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"/>
                  <span className={`absolute top-4 left-4 text-[11px] font-semibold px-3 py-1.5 rounded-full backdrop-blur ${p.accent==="cyan"?"bg-cyan-400/90 text-black":p.accent==="rose"?"bg-rose-500/90 text-white":"bg-violet-500/90 text-white"}`}>{p.cat}</span>
                  <button onClick={(e)=>{e.stopPropagation(); setLiked(v=>v.includes(p.id)?v.filter(x=>x!==p.id):[...v,p.id]);}} className="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/50 backdrop-blur grid place-items-center hover:scale-110 transition"><Heart className={`w-4 h-4 ${liked.includes(p.id)?"fill-rose-500 text-rose-500":"text-white"}`}/></button>
                  <span className="absolute bottom-4 left-4 font-display font-bold text-lg">{p.metric}</span><span className="absolute bottom-4 right-4 text-[11px] text-zinc-300 bg-black/50 backdrop-blur px-2 py-1 rounded-md">{p.metricLabel}</span>
                </div>
                <div className="p-6">
                  <h3 className="font-display text-xl font-bold group-hover:text-cyan-300 transition flex items-start justify-between gap-2">{p.title}<ArrowUpRight className="w-5 h-5 shrink-0 text-zinc-500 group-hover:text-white group-hover:rotate-45 transition"/></h3>
                  <p className="text-sm text-zinc-400 leading-relaxed mt-2 line-clamp-2">{p.desc}</p>
                  <div className="flex flex-wrap gap-1.5 mt-4">{p.tags.map(t=><span key={t} className="text-[11px] bg-white/5 border border-white/10 px-2.5 py-1 rounded-full text-zinc-300">{t}</span>)}</div>
                  <p className="mt-4 pt-4 border-t border-white/8 text-sm flex items-center gap-2"><Rocket className="w-4 h-4 text-emerald-400"/><span className="text-emerald-300 font-medium">{p.result}</span></p>
                </div>
              </article>
            ))}
          </div>
          {filtered.length===0 && <p className="text-center text-zinc-500 py-16">No projects here yet.</p>}
        </div>
      </section>

      {/* SHOWREEL LAB */}
      <section id="showreel" className="py-24 relative overflow-hidden">
        <div className="absolute -left-24 top-1/3 w-[420px] h-[420px] bg-rose-500/10 blur-[130px] rounded-full"/>
        <div className="max-w-7xl mx-auto px-5 lg:px-8 relative">
          <div className="reveal text-center max-w-2xl mx-auto">
            <p className="font-mono2 text-xs tracking-[0.3em] text-violet-300">03 — THE EDITING LAB</p>
            <h2 className="font-display text-4xl sm:text-5xl font-bold mt-3">Don't just watch.<br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 to-rose-400">Drive the timeline.</span></h2>
            <p className="text-zinc-400 mt-4 text-sm leading-relaxed">A working slice of my editing desk. Press play, click anywhere on the timeline to scrub, and watch the preview, timecode & clips react — exactly like my real Premiere timeline.</p>
          </div>

          <div className="reveal mt-12 rounded-[28px] border border-white/10 bg-[#0c0c14] overflow-hidden shadow-2xl">
            <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-3.5 border-b border-white/8 bg-white/[0.03]">
              <div className="flex items-center gap-3"><span className="flex gap-2"><span className="w-3 h-3 rounded-full bg-rose-500"/><span className="w-3 h-3 rounded-full bg-amber-400"/><span className="w-3 h-3 rounded-full bg-emerald-400"/></span><span className="font-mono2 text-xs text-zinc-400 ml-1">SHOWREEL_2025 — Sequence 01</span></div>
              <div className="flex items-center gap-2 text-xs font-mono2"><span className="bg-white/5 border border-white/10 px-2.5 py-1 rounded-md">4K • 24FPS</span><span className="bg-rose-500/15 text-rose-300 border border-rose-400/20 px-2.5 py-1 rounded-md">{activeClip.name}</span></div>
            </div>

            <div className="grid lg:grid-cols-12">
              <div className="lg:col-span-8 relative bg-black min-h-[300px] sm:min-h-[380px]">
                <img key={activeClip.name} src={activeClip.img} alt={activeClip.label} className="absolute inset-0 w-full h-full object-cover"/>
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/30"/>
                <div className="absolute top-4 left-4 flex gap-2"><span className="text-[10px] font-mono2 bg-black/60 backdrop-blur px-2.5 py-1 rounded-md">PROGRAM MONITOR</span>{playing && <span className="text-[10px] font-mono2 bg-rose-500 px-2.5 py-1 rounded-md flex items-center gap-1.5"><span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"/>PLAYING</span>}</div>
                <div className="absolute bottom-5 left-5 right-5 flex items-end justify-between gap-4">
                  <div><p className="font-mono2 text-[10px] tracking-widest text-rose-300">NOW CUTTING</p><p className="font-display text-2xl font-bold mt-1">{activeClip.label}</p><p className="font-mono2 text-sm text-cyan-300 mt-1">{fmt(progress)} <span className="text-zinc-500">/ {fmt(DUR)}</span></p></div>
                  <button onClick={()=>{ if(progress>=DUR) setProgress(0); setPlaying(!playing); }} className="w-16 h-16 shrink-0 rounded-full bg-white text-black grid place-items-center hover:scale-110 transition shadow-2xl">{playing?<Pause className="w-6 h-6 fill-black"/>:<Play className="w-6 h-6 fill-black ml-1"/>}</button>
                </div>
              </div>
              <div className="lg:col-span-4 border-t lg:border-t-0 lg:border-l border-white/8 p-5 bg-white/[0.02]">
                <p className="font-mono2 text-[10px] tracking-[0.25em] text-zinc-500">CLIP BIN — CLICK TO JUMP</p>
                <div className="space-y-2.5 mt-4">
                  {reelClips.map(c=>{
                    const active = activeClip.name===c.name;
                    return <button key={c.name} onClick={()=>{setProgress(c.start+0.1); setPlaying(true);}} className={`w-full text-left flex gap-3 p-2.5 rounded-2xl border transition ${active?"border-rose-400/40 bg-rose-400/10":"border-white/8 bg-white/[0.03] hover:bg-white/5"}`}>
                      <img src={c.img} alt={c.label} className="w-20 h-14 rounded-xl object-cover shrink-0"/>
                      <span className="min-w-0"><span className="block text-sm font-semibold truncate">{c.label}</span><span className="block font-mono2 text-[11px] text-zinc-500 mt-0.5 truncate">{c.name}</span><span className={`inline-block mt-1.5 text-[10px] px-2 py-0.5 rounded-full ${active?"bg-rose-500 text-white":"bg-white/8 text-zinc-400"}`}>{fmt(c.start)} → {fmt(c.end)}</span></span>
                    </button>
                  })}
                </div>
                <div className="mt-5 p-4 rounded-2xl bg-black/50 border border-white/8">
                  <div className="flex justify-between text-xs"><span className="text-zinc-400 flex items-center gap-1.5"><Volume2 className="w-3.5 h-3.5"/> Audio Mix</span><span className="font-mono2 text-emerald-300">-6.2 dB • LOUDNESS ✓</span></div>
                  <div className="flex items-end gap-1 h-10 mt-3">{[18,30,14,36,22,40,16,32,20,38,24,34,15,28,37,19,31,26].map((h,i)=><span key={i} className={`flex-1 rounded-sm ${playing?"eq-bar":""} ${i%3===0?"bg-rose-400":"bg-emerald-400/80"}`} style={{height: playing? h : 8+(h%14), animationDelay:`${i*0.09}s`}}/>)}</div>
                  <div className="grid grid-cols-3 gap-2 mt-4 text-center">{[["LUT","Cinematic Teal"],["Grade","Rec.709 ✓"],["Export","H.264 • 45Mbps"]].map(([k,v])=><div key={k} className="bg-white/5 rounded-xl py-2 px-1"><p className="text-[9px] tracking-widest text-zinc-500">{k}</p><p className="text-[11px] font-semibold mt-0.5 truncate">{v}</p></div>)}</div>
                </div>
              </div>
            </div>

            {/* TIMELINE */}
            <div className="border-t border-white/8 p-5 bg-black/40">
              <div className="flex items-center gap-2 sm:gap-3 mb-4">
                <button onClick={()=>setProgress(0)} className="w-9 h-9 rounded-full bg-white/5 border border-white/10 grid place-items-center hover:bg-white/10"><SkipBack className="w-4 h-4"/></button>
                <button onClick={()=>{ if(progress>=DUR) setProgress(0); setPlaying(!playing); }} className="w-10 h-10 rounded-full bg-gradient-to-r from-violet-500 to-rose-500 grid place-items-center hover:scale-105 transition">{playing?<Pause className="w-4 h-4 fill-white"/>:<Play className="w-4 h-4 fill-white ml-0.5"/>}</button>
                <button onClick={()=>setProgress(DUR)} className="w-9 h-9 rounded-full bg-white/5 border border-white/10 grid place-items-center hover:bg-white/10"><SkipForward className="w-4 h-4"/></button>
                <span className="font-mono2 text-sm ml-1">{fmt(progress)}</span>
                <span className="ml-auto hidden sm:flex items-center gap-2 text-xs text-zinc-500"><Scissors className="w-3.5 h-3.5"/> {reelClips.length*14} cuts • <Wand2 className="w-3.5 h-3.5"/> Auto-reframe ON</span>
              </div>
              <div className="relative cursor-pointer group/tl" onClick={seek}>
                <div className="flex justify-between font-mono2 text-[9px] text-zinc-600 mb-1.5 px-10"><span>00:00</span><span>00:25</span><span>00:50</span><span>01:15</span><span>01:40</span></div>
                {/* playhead */}
                <div className="absolute top-4 bottom-0 z-20 pointer-events-none" style={{left:`calc(2.5rem + (100% - 2.5rem) * ${progress/DUR})`}}><div className="absolute -top-1 -translate-x-1/2 w-[13px] h-[13px] bg-rose-500 rotate-45 rounded-[3px] shadow"/><div className="w-px h-full bg-rose-500 mx-auto"/></div>
                {[
                  {label:"V2", clips:[{w:"38%",c:"bg-violet-500/80",t:"TITLE_FX"},{w:"30%",c:"bg-violet-400/60",t:"OVERLAY"},{w:"30%",c:"bg-purple-500/50",t:"LOGO_OUTRO"}]},
                  {label:"V1", clips: reelClips.map(c=>({w:`${c.end-c.start}%`, c:c.color+"/85", t:c.name}))},
                  {label:"A1", clips:[{w:"100%",c:"bg-emerald-500/35",t:"MUSIC — Epidemic Sound • licensed"}]},
                  {label:"A2", clips:[{w:"22%",c:"bg-teal-500/40",t:"SFX_WHOOSH"},{w:"34%",c:"bg-teal-500/40",t:"AMBIENCE"},{w:"42%",c:"bg-teal-500/40",t:"VO_BOOST"}]},
                ].map((track)=>(
                  <div key={track.label} className="flex items-center gap-0 mb-1.5">
                    <span className="w-10 shrink-0 font-mono2 text-[10px] text-zinc-500">{track.label}</span>
                    <div className="flex-1 flex gap-1 h-8">
                      {track.clips.map((cl,i)=><div key={i} style={{width:cl.w}} className={`${cl.c} rounded-md border border-white/20 px-2 flex items-center overflow-hidden hover:brightness-125 transition`}><span className="font-mono2 text-[9px] truncate text-white/90">{cl.t}</span></div>)}
                    </div>
                  </div>
                ))}
                <p className="text-[11px] text-zinc-600 mt-3 flex items-center gap-1.5"><MousePointerClick className="w-3.5 h-3.5"/> Click anywhere on the timeline to scrub the playhead — go ahead, try it.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SKILLS */}
      <section id="skills" className="py-24 bg-[#0a0a12] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-5 reveal">
              <p className="font-mono2 text-xs tracking-[0.3em] text-cyan-300">04 — ARSENAL</p>
              <h2 className="font-display text-4xl sm:text-5xl font-bold mt-3 leading-tight">Two toolboxes.<br/>Zero compromises.</h2>
              <p className="text-zinc-400 mt-4 text-sm leading-relaxed max-w-md">Every tool below is production-proven — not tutorial knowledge. Switch the tab and watch the bars. Proficiency measured in shipped projects, not certificates.</p>
              <div className="inline-flex p-1.5 rounded-2xl bg-white/5 border border-white/10 mt-7">
                <button onClick={()=>setSkillTab("eng")} className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition ${skillTab==="eng"?"bg-cyan-400 text-black":"text-zinc-300"}`}><span className="inline-flex items-center gap-2"><Braces className="w-4 h-4"/>Engineering</span></button>
                <button onClick={()=>setSkillTab("edit")} className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition ${skillTab==="edit"?"bg-gradient-to-r from-violet-500 to-rose-500 text-white":"text-zinc-300"}`}><span className="inline-flex items-center gap-2"><Layers className="w-4 h-4"/>Editing</span></button>
              </div>
              <div className="mt-8 rounded-3xl overflow-hidden border border-white/10 relative h-52 group">
                <img src={skillTab==="eng"?"https://images.pexels.com/photos/5473301/pexels-photo-5473301.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200":"https://images.pexels.com/photos/6253568/pexels-photo-6253568.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"} alt="Workspace" className="w-full h-full object-cover group-hover:scale-105 transition duration-700"/>
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 to-transparent flex items-end p-5"><p className="font-display font-bold">{skillTab==="eng"?"Where systems are born — 3AM, dual monitors, zero segfaults.":"Where stories are born — frame by frame, beat by beat."}</p></div>
              </div>
            </div>
            <div className="lg:col-span-7 reveal">
              <div className="space-y-5">
                {(skillTab==="eng"?engSkills:editSkills).map((s,i)=>(
                  <div key={s.name}>
                    <div className="flex justify-between text-sm mb-2"><span className="font-medium flex items-center gap-2"><span className={`w-6 h-6 rounded-md grid place-items-center text-[10px] font-mono2 ${skillTab==="eng"?"bg-cyan-400/15 text-cyan-300":"bg-rose-400/15 text-rose-300"}`}>0{i+1}</span>{s.name}</span><span className="font-mono2 text-zinc-400">{s.level}%</span></div>
                    <div className="h-2.5 rounded-full bg-white/8 overflow-hidden"><div className={`h-full rounded-full transition-all duration-1000 ${skillTab==="eng"?"bg-gradient-to-r from-cyan-400 to-violet-500":"bg-gradient-to-r from-violet-500 to-rose-500"}`} style={{width:`${s.level}%`}}/></div>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 mt-8">
                {(skillTab==="eng" ? ["C++","Python","TypeScript","React","Node.js","Go","PostgreSQL","Docker","AWS","TensorFlow","KiCad PCB","Git / CI"] : ["Premiere Pro","After Effects","DaVinci Resolve","Photoshop","Audition","CapCut Pro","Figma","Frame.io","Notion","Epidemic Sound","Topaz AI","OBS Studio"]).map(t=><span key={t} className="text-center text-[13px] bg-white/[0.04] border border-white/10 rounded-xl px-2 py-3 hover:border-white/30 hover:-translate-y-0.5 transition cursor-default">{t}</span>)}
              </div>
            </div>
          </div>

          {/* SERVICES */}
          <div className="grid md:grid-cols-3 gap-6 mt-20">
            {[
              {icon:MonitorPlay, color:"from-violet-500 to-rose-500", title:"Video Editing", price:"from $250 / video", items:["YouTube long-form & Shorts/Reels","Color grade + sound design included","Captions, hooks & thumbnail concepts","48h rush available"], tag:"MOST BOOKED"},
              {icon:Cpu, color:"from-cyan-400 to-violet-500", title:"Engineering Build", price:"from $1,800 / project", items:["Web apps, dashboards & MVPs","Embedded / IoT product firmware","AI & computer-vision features","Docs, tests & handover call"], tag:"HIGH VALUE"},
              {icon:Wand2, color:"from-amber-400 to-rose-500", title:"Build + Film Bundle", price:"custom quote", items:["I build your product AND its launch film","Product trailer + social cutdowns","Landing page that matches the film","One person. Zero handoff loss."], tag:"SIGNATURE ✦"},
            ].map((s)=>(
              <div key={s.title} className="reveal relative rounded-[26px] border border-white/10 bg-white/[0.03] p-7 hover:border-white/25 hover:-translate-y-1 transition group">
                <span className="absolute -top-3 right-6 text-[10px] font-bold tracking-wider bg-white text-black px-3 py-1 rounded-full">{s.tag}</span>
                <span className={`w-13 h-13 w-[52px] h-[52px] rounded-2xl bg-gradient-to-br ${s.color} grid place-items-center`}><s.icon className="w-6 h-6"/></span>
                <h3 className="font-display text-2xl font-bold mt-5">{s.title}</h3><p className="font-mono2 text-sm text-cyan-300 mt-1">{s.price}</p>
                <ul className="mt-5 space-y-2.5 text-sm text-zinc-300">{s.items.map(x=><li key={x} className="flex gap-2.5"><Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5"/>{x}</li>)}</ul>
                <a href="#contact" className="mt-7 flex items-center justify-center gap-2 w-full py-3 rounded-xl border border-white/15 font-semibold text-sm group-hover:bg-white group-hover:text-black transition">Start a project <ArrowRight className="w-4 h-4"/></a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS + TIMELINE */}
      <section id="process" className="py-24">
        <div className="max-w-7xl mx-auto px-5 lg:px-8">
          <div className="reveal"><p className="font-mono2 text-xs tracking-[0.3em] text-amber-300">05 — HOW I WORK</p><h2 className="font-display text-4xl sm:text-5xl font-bold mt-3">A pipeline, not a gamble.</h2></div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mt-12">
            {[["01","Discover","We align on goals, audience & references. You get scope, fixed quote and timeline — in writing, within 12h."],["02","Prototype / Rough Cut","Fast first version you can actually react to — wireframe & working build, or a rough cut with temp grade."],["03","Refine","Two structured revision rounds. I iterate on data: retention graphs for video, tests & metrics for code."],["04","Ship & Support","Final delivery, exports in every format, source files & docs. Plus 14 days of free post-launch support."]].map(([n,t,d],i)=>(
              <div key={n} className="reveal relative rounded-[24px] border border-white/10 bg-white/[0.03] p-6 hover:bg-white/[0.05] transition overflow-hidden">
                <span className="font-display text-[64px] leading-none font-bold text-white/[0.07] absolute -top-2 right-3">{n}</span>
                <span className={`relative w-10 h-10 rounded-xl grid place-items-center font-display font-bold ${i%2===0?"bg-cyan-400 text-black":"bg-gradient-to-br from-violet-500 to-rose-500"}`}>{n}</span>
                <h3 className="relative font-display text-xl font-bold mt-5">{t}</h3><p className="relative text-sm text-zinc-400 leading-relaxed mt-2">{d}</p>
              </div>
            ))}
          </div>

          <div className="grid lg:grid-cols-12 gap-10 mt-20">
            <div className="lg:col-span-7 reveal">
              <h3 className="font-display text-3xl font-bold">The journey so far</h3>
              <div className="mt-8 space-y-0">
                {[["2023 — Now","Freelance — Engineer × Editor","36+ clients, 9 countries. Building products by day, cutting films by night. 48M+ views and counting.","bg-rose-500"],["2022 — 2023","Senior Software Engineer @ TechNova","Led a 4-person team shipping IoT dashboards. Nights: edited for creators up to 800k subs.","bg-violet-500"],["2021 — 2022","Embedded Engineer @ PulseWear","Firmware for health wearables — the PulseOS project. Fell in love with filming our product tests.","bg-cyan-400"],["2020 — 2021","B.E. Computer Engineering — Graduated","Honors, final-year Edge-AI capstone. Also cut my first viral video from hostel footage: 2.1M views.","bg-amber-400"]].map(([d,t,desc,c],i,arr)=>(
                  <div key={t} className="flex gap-5">
                    <div className="flex flex-col items-center"><span className={`w-4 h-4 rounded-full ${c} ring-4 ring-white/10 shrink-0 mt-1.5`}/>{i<arr.length-1 && <span className="w-px flex-1 bg-white/12 my-1"/>}</div>
                    <div className="pb-9"><p className="font-mono2 text-xs text-zinc-500">{d}</p><p className="font-display font-bold text-lg mt-1">{t}</p><p className="text-sm text-zinc-400 leading-relaxed mt-1 max-w-lg">{desc}</p></div>
                  </div>
                ))}
              </div>
            </div>
            {/* TESTIMONIAL */}
            <div className="lg:col-span-5 reveal">
              <div className="rounded-[26px] border border-white/10 bg-gradient-to-b from-violet-500/10 to-transparent p-7 sm:p-8 h-full flex flex-col">
                <div className="flex justify-between items-start"><Quote className="w-9 h-9 text-violet-400"/><div className="flex gap-2"><button onClick={()=>setTesti((testi-1+testimonials.length)%testimonials.length)} className="w-9 h-9 rounded-full border border-white/15 grid place-items-center hover:bg-white/10"><ChevronLeft className="w-4 h-4"/></button><button onClick={()=>setTesti((testi+1)%testimonials.length)} className="w-9 h-9 rounded-full border border-white/15 grid place-items-center hover:bg-white/10"><ChevronRight className="w-4 h-4"/></button></div></div>
                <p key={testi} className="font-display text-[21px] leading-relaxed font-medium mt-6 flex-1">"{testimonials[testi].quote}"</p>
                <div className="flex items-center gap-3 mt-7"><span className={`w-12 h-12 rounded-full ${testimonials[testi].color} grid place-items-center font-bold`}>{testimonials[testi].initials}</span><div><p className="font-semibold">{testimonials[testi].name}</p><p className="text-sm text-zinc-400">{testimonials[testi].role}</p></div><span className="ml-auto flex gap-0.5">{[1,2,3,4,5].map(i=><Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400"/>)}</span></div>
                <div className="flex gap-2 mt-6">{testimonials.map((_,i)=><button key={i} onClick={()=>setTesti(i)} className={`h-1.5 rounded-full transition-all ${i===testi?"w-8 bg-rose-400":"w-3 bg-white/20"}`}/>)}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ + CONTACT */}
      <section id="contact" className="py-24 bg-[#0a0a12] border-t border-white/5 relative overflow-hidden">
        <div className="absolute -bottom-24 left-1/3 w-[500px] h-[300px] bg-cyan-500/10 blur-[120px] rounded-full"/>
        <div className="max-w-7xl mx-auto px-5 lg:px-8 relative">
          <div className="grid lg:grid-cols-12 gap-12">
            <div className="lg:col-span-5 reveal">
              <p className="font-mono2 text-xs tracking-[0.3em] text-cyan-300">06 — LET'S TALK</p>
              <h2 className="font-display text-4xl sm:text-5xl font-bold mt-3 leading-tight">Have footage?<br/>Have an idea?<br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-rose-400">I have both brains.</span></h2>
              <div className="space-y-3 mt-8 text-sm">
                <a href="mailto:hello@alexcarter.dev" className="flex items-center gap-3 p-4 rounded-2xl border border-white/10 bg-white/[0.03] hover:border-cyan-400/40 transition"><Mail className="w-5 h-5 text-cyan-300"/> hello@alexcarter.dev <ArrowUpRight className="w-4 h-4 ml-auto text-zinc-500"/></a>
                <div className="flex items-center gap-3 p-4 rounded-2xl border border-white/10 bg-white/[0.03]"><Calendar className="w-5 h-5 text-rose-300"/> Next availability: <b>2 slots — this month</b></div>
                <div className="flex items-center gap-3 p-4 rounded-2xl border border-white/10 bg-white/[0.03]"><MapPin className="w-5 h-5 text-violet-300"/> Remote worldwide • UTC-5 to UTC+5 friendly</div>
              </div>
              <div className="flex gap-2.5 mt-6">{[{icon:Globe,label:"GH"},{icon:AtSign,label:"IN"},{icon:MonitorPlay,label:"YT"},{icon:Camera,label:"IG"},{icon:MessageCircle,label:"X"}].map(({icon:Icon,label},i)=><a key={i} href="#contact" title={label} className="w-11 h-11 rounded-full border border-white/10 grid place-items-center hover:bg-white hover:text-black transition"><Icon className="w-5 h-5"/></a>)}</div>
              {/* FAQ */}
              <div className="mt-10 space-y-3">
                <p className="font-display font-bold text-lg">Quick answers</p>
                {faqs.map((f,i)=>(
                  <div key={f.q} className="rounded-2xl border border-white/10 bg-white/[0.03] overflow-hidden">
                    <button onClick={()=>setOpenFaq(openFaq===i?-1:i)} className="w-full flex items-center justify-between gap-3 text-left px-5 py-4 font-medium text-sm">{f.q}<ChevronDown className={`w-4 h-4 shrink-0 transition ${openFaq===i?"rotate-180":""}`}/></button>
                    {openFaq===i && <p className="px-5 pb-5 text-sm text-zinc-400 leading-relaxed">{f.a}</p>}
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-7 reveal">
              <div className="rounded-[28px] border border-white/10 bg-white/[0.03] p-6 sm:p-9">
                {sent ? (
                  <div className="text-center py-14">
                    <span className="w-20 h-20 rounded-full bg-emerald-400/15 border border-emerald-400/30 grid place-items-center mx-auto"><Check className="w-9 h-9 text-emerald-300"/></span>
                    <h3 className="font-display text-3xl font-bold mt-6">Message received, {form.name.split(" ")[0] || "friend"}!</h3>
                    <p className="text-zinc-400 mt-3 max-w-md mx-auto text-sm leading-relaxed">Your {form.type.toLowerCase()} brief just landed in my inbox. Expect a reply with scope, timeline & next steps within <b className="text-white">12 hours</b>.</p>
                    <div className="inline-flex gap-2 mt-6 font-mono2 text-xs"><span className="bg-white/5 border border-white/10 px-3 py-2 rounded-lg">TICKET #AC-{Math.floor(1000+ (form.email.length*137)%9000)}</span><span className="bg-emerald-400/10 text-emerald-300 border border-emerald-400/20 px-3 py-2 rounded-lg">STATUS: QUEUED ✓</span></div>
                    <button onClick={()=>setSent(false)} className="block mx-auto mt-8 text-sm text-cyan-300 hover:underline">Send another message</button>
                  </div>
                ) : (
                  <form onSubmit={(e)=>{e.preventDefault(); setSent(true);}} className="space-y-5">
                    <div className="flex items-center justify-between"><h3 className="font-display text-2xl font-bold">Start a project</h3><span className="text-xs font-mono2 bg-emerald-400/10 text-emerald-300 border border-emerald-400/20 px-3 py-1.5 rounded-full">● AVG REPLY: 4H 12M</span></div>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div><label className="text-sm font-medium">Your name *</label><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Jane Smith" className="mt-2 w-full bg-black/40 border border-white/12 rounded-xl px-4 py-3.5 text-sm placeholder:text-zinc-600 transition"/></div>
                      <div><label className="text-sm font-medium">Email *</label><input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="jane@company.com" className="mt-2 w-full bg-black/40 border border-white/12 rounded-xl px-4 py-3.5 text-sm placeholder:text-zinc-600 transition"/></div>
                    </div>
                    <div>
                      <label className="text-sm font-medium">What are we creating?</label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">{["Video Editing Project","Engineering Project","Build + Film Bundle","Something Else"].map(t=><button type="button" key={t} onClick={()=>setForm({...form,type:t})} className={`px-3 py-3 rounded-xl text-[13px] font-medium border transition ${form.type===t?"bg-white text-black border-white":"border-white/12 bg-black/30 text-zinc-300 hover:border-white/30"}`}>{t}</button>)}</div>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Budget range</label>
                      <div className="flex flex-wrap gap-2 mt-2">{["Under $500","$500 – $1k","$1k – $5k","$5k+"].map(b=><button type="button" key={b} onClick={()=>setForm({...form,budget:b})} className={`px-4 py-2.5 rounded-full text-sm border transition ${form.budget===b?"bg-cyan-400 text-black border-cyan-400 font-semibold":"border-white/12 text-zinc-300 hover:border-white/30"}`}>{b}</button>)}</div>
                    </div>
                    <div><label className="text-sm font-medium">Tell me about it *</label><textarea required rows={4} value={form.msg} onChange={e=>setForm({...form,msg:e.target.value})} placeholder={form.type.includes("Video")?"Links to raw footage, references you love, deadline...":"What are we building, who is it for, what does success look like..."} className="mt-2 w-full bg-black/40 border border-white/12 rounded-xl px-4 py-3.5 text-sm placeholder:text-zinc-600 resize-none transition"/></div>
                    <button className="w-full py-4 rounded-2xl bg-gradient-to-r from-cyan-400 via-violet-500 to-rose-500 font-display font-bold text-[17px] hover:opacity-90 hover:scale-[1.01] transition flex items-center justify-center gap-2">Send Message <Send className="w-4.5 h-4.5 w-5 h-5"/></button>
                    <p className="text-center text-xs text-zinc-600">No spam, no obligation. NDA-friendly. Your footage & ideas stay 100% yours.</p>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-white/8 py-10">
        <div className="max-w-7xl mx-auto px-5 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-5">
          <div className="flex items-center gap-3"><span className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-400 via-violet-500 to-rose-500 grid place-items-center font-display font-bold">A</span><p className="text-sm text-zinc-400">© 2025 Alex Carter — Built with React. Cut like a film. <span className="text-zinc-600 font-mono2 text-xs ml-1">v9_final_FINAL2.mp4</span></p></div>
          <div className="flex items-center gap-6 text-sm text-zinc-400"><a href="#work" className="hover:text-white">Work</a><a href="#showreel" className="hover:text-white">Showreel</a><a href="#top" className="hover:text-white inline-flex items-center gap-1.5">Back to top <ArrowUpRight className="w-4 h-4"/></a></div>
        </div>
      </footer>

      {/* PROJECT MODAL */}
      {selected && (
        <div className="fixed inset-0 z-[80] bg-black/80 backdrop-blur-sm grid place-items-center p-4" onClick={()=>setSelected(null)}>
          <div className="w-full max-w-2xl rounded-[26px] bg-[#101018] border border-white/12 overflow-hidden max-h-[90vh] overflow-y-auto" onClick={e=>e.stopPropagation()}>
            <div className="relative h-64 sm:h-72"><img src={selected.img} alt={selected.title} className="w-full h-full object-cover"/><div className="absolute inset-0 bg-gradient-to-t from-[#101018] to-transparent"/><button onClick={()=>setSelected(null)} className="absolute top-4 right-4 w-10 h-10 rounded-full bg-black/60 backdrop-blur grid place-items-center hover:rotate-90 transition"><X className="w-5 h-5"/></button><span className="absolute bottom-4 left-6 text-xs font-semibold bg-white text-black px-3 py-1.5 rounded-full">{selected.cat}</span></div>
            <div className="p-6 sm:p-8">
              <h3 className="font-display text-3xl font-bold">{selected.title}</h3>
              <p className="text-zinc-400 leading-relaxed mt-3">{selected.desc}</p>
              <div className="grid grid-cols-3 gap-3 mt-6 text-center">{[[selected.metric,"Headline Result"],[selected.result,"Outcome"],["14 days","Delivery Time"]].map(([v,l])=><div key={l} className="bg-white/[0.04] border border-white/10 rounded-2xl p-4"><p className="font-display font-bold text-sm sm:text-base leading-tight">{v}</p><p className="text-[11px] text-zinc-500 mt-1">{l}</p></div>)}</div>
              <div className="flex flex-wrap gap-2 mt-6">{selected.tags.map(t=><span key={t} className="text-xs bg-white/5 border border-white/10 px-3 py-1.5 rounded-full">{t}</span>)}</div>
              <div className="flex gap-3 mt-8"><a href="#contact" onClick={()=>setSelected(null)} className="flex-1 text-center py-3.5 rounded-xl bg-white text-black font-semibold hover:bg-cyan-300 transition">I want something like this</a><button onClick={()=>setSelected(null)} className="px-6 py-3.5 rounded-xl border border-white/15 font-semibold hover:bg-white/5 transition">Close</button></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
